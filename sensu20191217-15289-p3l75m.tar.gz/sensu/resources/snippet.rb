actions :create, :delete
default_action :create

attribute :content, :required => true
